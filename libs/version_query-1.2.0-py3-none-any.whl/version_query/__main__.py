"""Entry point of the command-line interface of version_query package."""

from .main import main


if __name__ == '__main__':
    main()
