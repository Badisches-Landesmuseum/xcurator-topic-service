import re
import os

from typing import Iterable
from trie import Trie


class StopWordService:

    __instance = None
    STOP_WORD_DIR = os.path.join(os.path.dirname(__file__), 'resources/stopwords')
    languages = ['german','english']
    stop_words_by_language = dict()

    @staticmethod
    def get_instance():
        if StopWordService.__instance == None:
            StopWordService()
        return StopWordService.__instance

    def __init_language_trie(self, language:str):
        stop_words = self.get(language)
        self.add(language, stop_words)

    def __init__(self):
        if StopWordService.__instance != None:
            raise Exception("This class is a Singleton! Please use get_instance().")
        else:
            StopWordService.__instance = self

        for language in self.languages:
            self.__init_language_trie(language)

    def get(self, language: str = 'german') -> Iterable[str]:
        '''
        Load a pre-defined stop word list by language.

        :param language: language as string (e.g. german)
        :return: language specific stop word list
        '''

        if language not in self.languages:
            raise ValueError('language ('+language+') not supported!')

        path = os.path.join(self.STOP_WORD_DIR, language)
        return self.load_from_disk(path)

    @staticmethod
    def load_from_disk(path: str) -> Iterable[str]:
        '''
        load a stop word directory from the disc. Be aware that a txt is given. The words are separated by new lines.

        :param path: path to the directory file
        :return: lower cased word list
        '''
        with open(path) as wordbook:
            return set(word.strip().lower() for word in wordbook)

    def add(self, language: str, stop_words: Iterable[str]):
        self.stop_words_by_language[language] = stop_words

    @staticmethod
    def build_trie_regex_pattern(words: Iterable[str]) -> re:
        trie = Trie()
        for word in words:
            trie.add(word)
        return re.compile(r'\b' + trie.pattern() + r'\b', re.IGNORECASE | re.UNICODE | re.MULTILINE)


