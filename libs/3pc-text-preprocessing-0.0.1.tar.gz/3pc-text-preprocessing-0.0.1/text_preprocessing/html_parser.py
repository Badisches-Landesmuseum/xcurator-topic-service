from selectolax.parser import HTMLParser

class HtmlParser(HTMLParser):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def get_text(self, root_css_class:str=None, css_classes=[], separator="\n"):
        node = self.css_first(root_css_class) if root_css_class else self.body

        if css_classes:
            css_selector = ','.join(['.' + css_class for css_class in css_classes])
            texts = [tag.text().strip() for tag in node.css(css_selector)]
            return separator.join(texts)
        else:
            return node.text().strip()

    def get_text_position(self, root:str = None, classes=[]):
        body = self.css_first(root) if root else self.body

        if classes:
            css_selector = ','.join(['.' + css_class for css_class in classes])
            tree = body.css(css_selector)
        else:
            tree = [body]

        test = []
        node_id = 0
        for node in tree:
            node_id += 1
            node_pos = self.html.find(node.html)
            for tag in node.css('script,style,img'):
                tag.decompose()

            for child_node in node.traverse():
                if child_node.tag in ['script','style','img']:
                    continue
                text = child_node.text(deep=False)
                if not text.strip():
                    continue
                child_node_start = node.html.find(child_node.html)
                text_start = child_node.html.find('>') + 1
                start_pos = node_pos + child_node_start + text_start
                text_end = node_pos + child_node_start + child_node.html.rfind('<') + 1

                test.append((text,start_pos, text_end,child_node.tag, node_id))