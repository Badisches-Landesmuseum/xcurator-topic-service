import re
from typing import List, Iterable

import unicodedata

from text_preprocessing.html_parser import HtmlParser


class TextCleanUtil:
    HTML_ENTITY = r'(?:&[a-z]{2,};)|(?:&#[0-9]{2,};)'
    QUOTATION_MARK = r'[\'\"]+'
    SINGLE_CHAR_WORD = r'(?<!\S)([\wüöäÜÖÄß]{1})((?:^|$)|(?!\S))'
    MULTI_PUNCTUATION = r'[\[\(\?\.\!:_\-\,]{2,}'
    MULTI_WHITESPACE = r'( ){2,}'
    BRACKETS = r'[\(\)\[\]\{\}]+'
    NUMBERS = r'[0-9]+'

    @classmethod
    def remove_from_text(cls, text: str, regex_pattern: re) -> str:
        '''
        Remove a string part by regex match.
        :param text: input text
        :param regex_pattern:  regular expression
        :return: cleaned input string
        '''
        return re.sub(regex_pattern, '', text)

    @classmethod
    def swap_match(cls, text: str, regex_pattern: re) -> str:
        '''
        Remove a string part by regex match.
        :param text: input text
        :param regex_pattern:  regular expression
        :return: cleaned input string
        '''
        return re.sub(regex_pattern, r'\2\1', text)

    @classmethod
    def remove_combined_from_text(cls, text: str, regex_patterns: List[str]) -> str:
        '''
        Remove a string part by a regex union match.
        The list of regex will be combined (union) to a single regex for faster cleaning.

        :param text: input text
        :param regex_patterns: list of regex pattern
        :return: cleaned input string
        '''
        regex_union = '(' + '|'.join(regex_patterns) + ')'
        return re.sub(regex_union, '', text)

    @classmethod
    def handle_html_entities(cls, text: str) -> str:
        '''
        Convert known HTML Entities to UTF-8 representation and clean unknown HTML Entities.
        (&cent; -> ¢)

        :param text: input text
        :return: cleaned input string
        '''
        if not cls.contains_html_entity(text):
            return text

        text = text.replace("&nbsp;", " ") \
            .replace("&lt;", "<") \
            .replace("&gt;", ">") \
            .replace("&amp;", "&") \
            .replace("&quot;", "\"") \
            .replace("&apos;", "'") \
            .replace("&cent;", "¢") \
            .replace("&pound;", "£") \
            .replace("&yen;", "¥") \
            .replace("&euro;", "€") \
            .replace("&copy;", "©") \
            .replace("&reg;", "®")

        return cls.remove_from_text(text, cls.HTML_ENTITY)

    @classmethod
    def contains_html_entity(cls, text: str) -> bool:
        '''
        Check if the input string contains HTML Entities
        :param text:  input text
        :return: true | false
        '''
        return bool(re.search(cls.HTML_ENTITY, text))

    @classmethod
    def contains_multi_whitespace(cls, text: str) -> bool:
        '''
        Check if the input string contains multiple whitespaces
        :param text:  input text
        :return: true | false
        '''
        return bool(re.search(cls.MULTI_WHITESPACE, text))

    @classmethod
    def strip_accents_and_umlaute(cls, text: str) -> str:
        '''
        Replace accents from text with their nearest ASCII representation
        (è -> e | ö -> o)

        :param text: input text
        :return: text without accents and umlaute
        '''
        nfkd_form = unicodedata.normalize('NFKD', text)
        return u"".join([c for c in nfkd_form if not unicodedata.combining(c)])

    @classmethod
    def remove_quotation_marks(cls, text: str) -> str:
        '''
        Example 'text' -> Example text

        :param text:
        :return:
        '''
        return cls.remove_from_text(text, cls.QUOTATION_MARK)

    @classmethod
    def remove_multi_punctuations(cls, text: str) -> str:
        """
        'Example text.:' -> 'Example text'

        :param text: input text
        :return: text without multi punktiation
        """
        return cls.remove_from_text(text, cls.MULTI_PUNCTUATION)

    @classmethod
    def remove_single_char_words(cls, text: str) -> str:
        '''
        Example A Text -> Example Text

        :param text: input text
        :return: text without single char words
        '''
        return cls.remove_from_text(text, cls.SINGLE_CHAR_WORD)

    @classmethod
    def remove_brackets(cls, text: str) -> str:
        '''
        Example (text) -> Example text

        :param text:  input text
        :return: text without brackets
        '''
        return cls.remove_from_text(text, cls.BRACKETS)

    @classmethod
    def replace_numbers_with_constant(cls, text: str, constant: str = '#') -> str:
        '''
        Example 12 texts -> Example ## texts

        :param text: input text
        :param constant: constant string to replace (default: #)
        :return: text with replaced numbers
        '''
        if not constant:
            raise ValueError("No constant for replacement given!")
        return re.sub(cls.NUMBERS, constant, text)

    @classmethod
    def html_to_text(cls, html_content: str) -> str:
        '''
        Extract Text from HTML using an HTML Parser

        <p>Example text</p> -> Example text

        :param html_content: html input string
        :return: text without html markup
        '''
        html_content = TextCleanUtil.handle_html_entities(html_content)
        html_parser = HtmlParser(html_content)
        return html_parser.get_text()

    @classmethod
    def swap_punctuation(cls, text: str) -> str:
        '''
        Swap / Correct the punctuation position in a text.

        Example text . Example sentence. -> Example text. Example sentence.

        :param text: input text
        :return: text with swapped punctuation
        '''
        # ' .' -> '. '
        backward_swap = cls.swap_match(text, r'( )([\.\,\?\!\:\;\]\)\}])')
        # ( ...) -> (...)
        return cls.swap_match(backward_swap, r'(\(\[\{)( )')

    @classmethod
    def clean_with_alphabet(cls, text: str, regex_alphabet: str = r'a-zA-ZöäüÖÄÜ0-9\s\.\,@\)\(\]\[\}\{\;\s:') -> str:
        '''
        Removes all chars from the text which are NOT defined in the regex_alphabet.

        :param text: input text
        :param regex_alphabet: regex alphabet of chars to keep
        :return: text without any chars NOT in the regex_alphabet
        '''
        return cls.remove_from_text(text, r'[^'+regex_alphabet+']')

    @classmethod
    def remove_words(cls, text:str, words: Iterable[str]) -> str:
        '''
        Remove all given words from a text and removes multi-whitespace.

        :param text:  input text
        :param words:  word list to remove (e.g. stop word list)
        :return: text without the given words AND non multi-whitespace
        '''
        words = [word for word in text.split() if word not in words]
        return ' '.join(words)
