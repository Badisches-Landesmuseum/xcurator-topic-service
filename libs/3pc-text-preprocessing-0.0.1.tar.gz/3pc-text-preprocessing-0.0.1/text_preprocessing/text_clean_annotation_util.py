import re
from typing import Iterable

from text_preprocessing.text_clean_util import TextCleanUtil


class TextAnnotationCleanUtil(TextCleanUtil):

    MULTIPLE_WHITESPACE = re.compile(' {2,}')

    @classmethod
    def replace_pattern_match_with_constant(cls, match, constant: str) -> str:
        return constant * len(match.group())

    @classmethod
    def replace_pattern_match_with_whitespace(cls, match) -> str:
        return cls.replace_pattern_match_with_constant(match, ' ')

    @classmethod
    def remove_from_text(cls, text: str, regex_pattern: re) -> str:
        return re.sub(regex_pattern, cls.replace_pattern_match_with_whitespace, text)

    def remove_multi_whitespace(text: str) -> str:
        return re.sub(' {2,}', " ", text)

    @classmethod
    def replace_numbers_with_constant(cls, text:str, constant:str = '#') -> str:
        return re.sub(cls.NUMBERS, lambda x: cls.replace_pattern_match_with_constant(x,constant), text)

    @classmethod
    def handle_html_entities(cls, text: str) -> str:

        if not cls.contains_html_entity(text):
            return text

        text = text.replace("&nbsp;", "      ") \
            .replace("&lt;", " <  ") \
            .replace("&gt;", "  > ") \
            .replace("&amp;", " &   ") \
            .replace("&quot;", " \"    ") \
            .replace("&apos;", " '    ") \
            .replace("&cent;", " ¢    ") \
            .replace("&pound;", " £     ") \
            .replace("&yen;", " ¥   ") \
            .replace("&euro;", " €    ") \
            .replace("&copy;", " ©    ") \
            .replace("&reg;", " ®   ")

        return cls.remove_from_text(text, cls.HTML_ENTITY)

    # POSITIONING BETWEEN ORIGINAL TEXT AND CLEANED TEXT
    @classmethod
    def whitespace_to_position_map_handling(cls, text: str):
        position_map = []

        # remove leading whitespace
        leading_striped_text = text.lstrip()
        leading_striped_length_diff = len(text) - len(leading_striped_text)
        position_map.insert(0, [0, leading_striped_length_diff])

        # remove tailing whitespace
        tailing_striped_text = leading_striped_text.rstrip()
        tailing_striped_length_diff = len(leading_striped_text) - len(tailing_striped_text)

        # remove whitespace in between with positions
        previous_removed_whitespace_count = 0
        for multi_whitespace_match in cls.MULTIPLE_WHITESPACE.finditer(tailing_striped_text):
            match_start_position = multi_whitespace_match.start() - previous_removed_whitespace_count + 1

            # replace multi whitespaces with a single whitespace | 4 whitespaces will be 3 whitespaces -> -1
            current_char_remove_count = multi_whitespace_match.end() - multi_whitespace_match.start() - 1
            orig_clean_text_dela_count = current_char_remove_count + previous_removed_whitespace_count + leading_striped_length_diff

            position_map.append([match_start_position, orig_clean_text_dela_count])
            tailing_striped_text = tailing_striped_text[
                                   :multi_whitespace_match.start() - previous_removed_whitespace_count] + " " + tailing_striped_text[
                                                                                                                multi_whitespace_match.end() - previous_removed_whitespace_count:]

            previous_removed_whitespace_count = previous_removed_whitespace_count + current_char_remove_count

        # if tailing_striped_length_diff > 0:
        position_map.append([len(tailing_striped_text), tailing_striped_length_diff + position_map[-1][1]])

        return tailing_striped_text, position_map

    @classmethod
    def orig_text_to_cleaned_text_position_delta(cls, position_map, pos) -> int:
        for i in range(len(position_map) - 1):
            if position_map[i][0] <= pos < position_map[i + 1][0]:
                return position_map[i][1]
        return 0

    @classmethod
    def orig_text_to_cleaned_text_position(cls, position_map, clean_text_position, context_start_position=0) -> int:
        for i in range(len(position_map) - 1):
            if position_map[i][0] <= clean_text_position < position_map[i + 1][0]:
                return context_start_position + clean_text_position + position_map[i][1]
            # elif
        return context_start_position + clean_text_position

    @classmethod
    def remove_words(cls, text:str, words: Iterable[str]) -> str:
        '''
        Remove all given words from a text and removes multi-whitespace.

        :param text:  input text
        :param words:  word list to remove (e.g. stop word list)
        :return: text without the given words AND non multi-whitespace
        '''
        if cls.contains_multi_whitespace(text):
            raise ValueError("Text contains multi whitespace! The text removal would change the length of the text. Please handle multi whitespace properly bevore using the word removal")
        words = [' ' * len(word) if word in words else word for word in text.split()]
        return ' '.join(words)
