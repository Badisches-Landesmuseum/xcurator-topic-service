from unittest import TestCase

from converter.proto_converter import ProtoMessageConverter
from proto.asset.objectdetection import ObjectProto, PointProto


class TestProtoMessageConverter(TestCase):
    _converter = ProtoMessageConverter()
    _proto_object = ObjectProto(label="test",
                                confidence=0.93,
                                top_left=PointProto(x=1, y=100),
                                bottom_right=PointProto(x=450, y=360))

    def test_write_delimited(self):
        body = self._converter.encode_body(self._proto_object)
        self.assertIsNotNone(body)

    def test_read_delimited(self):
        body = self._converter.encode_body(self._proto_object)
        decoded = self._converter.get_body(body, ObjectProto)

        self.assertIsNotNone(body)
        self.assertTrue(isinstance(decoded, ObjectProto))
