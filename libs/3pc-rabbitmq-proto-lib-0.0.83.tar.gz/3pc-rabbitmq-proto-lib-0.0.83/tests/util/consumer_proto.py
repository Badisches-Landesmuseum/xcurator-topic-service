from aio_pika import IncomingMessage

from listener import RabbitListener
from proto.asset.objectdetection import ObjectProto


class TestProtoConsumer(RabbitListener):

    def __init__(self, number: int = 1):
        self.name = "proto-test-listener" + str(number)
        self.routing_keys = ['image.created.proto']
        self.exchange_name = 'assets'
        self.dead_letter_exchange = "assets-dlx"

    async def on_message(self, body: ObjectProto, message: IncomingMessage):
        print(self.name + " [x] Proto Received %r" % body.label)
        await self.convert_and_send("test.message", body, "assets")
        print("Done")
