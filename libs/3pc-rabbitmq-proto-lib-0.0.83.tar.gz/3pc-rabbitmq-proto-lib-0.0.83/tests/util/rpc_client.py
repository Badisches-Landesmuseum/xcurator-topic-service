from rpc_client import RabbitRPCClient


class TestRPC(RabbitRPCClient):

    def __init__(self):
        self.name = "test.rpc.client"

    async def call(self, message: str):
        future_result = self.convert_send_and_reply("image.created", message, "assets")
        return await future_result

    def echo(self, message) -> str:
        return self.convert_send_and_reply_sync("image.created", message, "assets")
