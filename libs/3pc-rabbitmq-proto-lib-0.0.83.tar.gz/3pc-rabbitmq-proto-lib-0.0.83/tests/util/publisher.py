import aiormq
from aio_pika import DeliveryMode

from publisher import RabbitPublisher


class TestPublisher(RabbitPublisher):

    def __init__(self):
        self.properties = aiormq.spec.Basic.Properties()
        self.properties.correlation_id = "123345"
        self.properties.delivery_mode = DeliveryMode.PERSISTENT
        self.properties.headers = {'TEST': "NEW_HEADER", "DREIPC_MESSAGE_TYPE": "BYTE"}

    def publish(self, message: str, n: int = 1):
        for i in range(n):
            self.convert_and_send_sync('image.created', message, 'assets', self.properties)
