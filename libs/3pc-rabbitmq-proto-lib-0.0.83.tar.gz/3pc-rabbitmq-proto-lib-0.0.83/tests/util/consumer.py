from aio_pika import IncomingMessage

from proto.asset.objectdetection import Yolo4DetectionActionProto
from rabbitmq_proto_lib.listener import RabbitListener


class TestConsumer(RabbitListener):

    def __init__(self, number: int = 1):
        self.name
        self.name = "test-listener" + str(number)
        self.routing_keys = ['image.created']
        self.exchange_name = 'assets'
        self.dead_letter_exchange = "assets-dlx"

    async def on_message(self, body: str, message: IncomingMessage):
        print(self.name + " [x] Received %r" % body)
        proto_body = Yolo4DetectionActionProto(file_url="http://example.com/nice.jpg")
        # await self.convert_and_send("test.message", proto_body, "assets")
        # print("Done sending answer")
        return body + " Reply Echo"
