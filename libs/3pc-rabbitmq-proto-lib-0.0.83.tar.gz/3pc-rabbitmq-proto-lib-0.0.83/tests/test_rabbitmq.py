from unittest import TestCase

# https://stackoverflow.com/questions/9508246/rabbitmq-pika-and-reconnection-strategy
from manager import RabbitManager


class TestRabbitMQ(TestCase):
    RABBIT_CONFIG = {'username': 'dreipc',
                     'password': 'password',
                     'host': 'localhost',
                     'port': 5672,
                     'vhost': '/'}

    def setUp(self) -> None:
        self.rabbitmq = RabbitManager(TestRabbitMQ.RABBIT_CONFIG)
        self.rabbitmq2 = RabbitManager(TestRabbitMQ.RABBIT_CONFIG)

    def test_init(self):
        self.assertIsNotNone(self.rabbitmq)

    def test_connect(self):
        self.rabbitmq.connect()
        self.rabbitmq2.connect()

        print("Test")

        # time.sleep(1)
        # self.rabbitmq.stop()

    def tearDown(self) -> None:
        self.rabbitmq.disconnect()
        self.rabbitmq2.disconnect()
