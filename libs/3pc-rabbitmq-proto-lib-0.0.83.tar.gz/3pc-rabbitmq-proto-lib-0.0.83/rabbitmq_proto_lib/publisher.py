import asyncio
import logging
from typing import Dict

import aio_pika
import aiormq
import betterproto

from rabbitmq_proto_lib.converter import RabbitMessageConverter
from rabbitmq_proto_lib.dreipc_message_header import DreiPCMessageHeader
from rabbitmq_proto_lib.exceptions import SerialisationException

is_ready = False


def _retry_on_not_ready(exception):
    is_retryable_error = isinstance(exception, AttributeError)
    if is_ready:
        logging.warning("Can't publish message because the rabbit connection is not established yet. Initiate Retry.")
    else:
        logging.error("Error during sending message! Error: " + str(exception))
    return is_ready


class RabbitPublisher:
    _channel: aio_pika.RobustChannel = None
    exchange_name: str = ""
    _exchange: aio_pika.Exchange = None
    _message_converter = None

    async def channel(self, channel):
        """Register a Channel used to send messages to the RabbitMQ Broker. This is used by the RabbitManager."""
        self._channel = channel
        self._exchange = await self._get_exchange(self.exchange_name)

    def add_message_converters(self, converters: Dict[str, RabbitMessageConverter]):
        """Register a Message Converter for decode / encoding Messages."""
        self._message_converter = converters

    @property
    def loop(self) -> asyncio.events:
        return self.__loop

    @loop.setter
    def loop(self, loop: asyncio.events):
        self.__loop = loop

    async def send(self, routing_key: str, message: aio_pika.Message,
                   exchange_name: str = None, properties: aiormq.spec.Basic.Properties = None):
        if properties:
            await self._merge_properties(message, properties)
        """Send a message to the RabbitMQ Broker."""
        exchange = await self._get_exchange(exchange_name)
        await exchange.publish(message, routing_key)

    async def _merge_properties(self, message: aio_pika.Message, properties: aiormq.spec.Basic.Properties):
        props = {k: v for k, v in properties.to_dict().items() if v}
        for key, value in props.items():
            try:
                if key == "headers":
                    for header_key, header_value in value.items():
                        message.headers[header_key] = header_value
                else:
                    message.__setattr__(key, value)
            except Exception as e:
                logging.warning("Error during merge of message properties: " + str(e))

    def send_sync(self, routing_key: str, message: aio_pika.Message,
                  exchange_name: str = None, properties: aiormq.spec.Basic.Properties = None):
        """Send a message to the RabbitMQ Broker."""
        return self.loop.run_until_complete(self.send(routing_key, message, exchange_name, properties))

    async def _get_exchange(self, exchange_name: str = None) -> aio_pika.Exchange:
        if exchange_name == "":
            return self._channel.default_exchange

        if not exchange_name:
            exchange_name = self.exchange_name

        if self._exchange and exchange_name == self._exchange.name:
            return self._exchange
        else:
            return await self._channel.declare_exchange(exchange_name, passive=True)

    async def convert_and_send(self, routing_key: str, body,
                               exchange_name: str = None, properties: aiormq.spec.Basic.Properties = None):
        """Convert the message body into a binary form,
        set common rabbitmq-message properties and
        send it to the given exchange (default: using rabbit default exchange if none is given)."""

        message = await self._create_proto_message(body)
        return await self.send(routing_key, message, exchange_name, properties)

    def convert_and_send_sync(self, routing_key: str, body,
                              exchange_name: str = None, properties: aiormq.spec.Basic.Properties = None):
        return self.loop.run_until_complete(self.convert_and_send(routing_key, body, exchange_name, properties))

    """
    HELPER
    """

    async def _get_message_converter(self, body) -> RabbitMessageConverter:
        if isinstance(body, str):
            return await self._get_message_converter_by_content_type("text/plain")
        elif isinstance(body, betterproto.Message):
            return await self._get_message_converter_by_content_type("application/protobuf")
        else:
            raise SerialisationException("Unknown message body type! Type: " + str(type(body)))

    async def _get_message_converter_by_content_type(self, content_type: str) -> RabbitMessageConverter:
        return self._message_converter[content_type]

    async def _create_proto_message(self, body) -> aio_pika.Message:
        message_converter = await self._get_message_converter(body)
        proto_message_body = await message_converter.encode_body(body)

        message = aio_pika.Message(proto_message_body)
        message.content_type = message_converter.content_type
        message.type = message_converter.get_named_type(body)
        message.headers[DreiPCMessageHeader.MESSAGE_TYPE] = message_converter.get_named_type(body)
        return message
