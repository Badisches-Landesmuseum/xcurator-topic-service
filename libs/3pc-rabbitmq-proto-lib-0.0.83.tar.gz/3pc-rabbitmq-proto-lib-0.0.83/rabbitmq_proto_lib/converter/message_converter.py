import inspect
from typing import TypeVar, Generic

T = TypeVar('T')
from aio_pika import IncomingMessage


class RabbitMessageConverter(Generic[T]):
    content_type: str = None

    def set_header(self, message: IncomingMessage) -> bytes:
        NotImplementedError()

    async def encode_body(self, body: T) -> bytes:
        NotImplementedError()

    async def decode_body(self, message: IncomingMessage) -> T:
        NotImplementedError()

    def get_named_type(self, body) -> str:
        if isinstance(body, str):
            return "STRING"
        elif isinstance(body, bytes):
            return "BYTES"
        elif inspect.isclass(body):
            return body.__name__.upper()
        else:
            return body.__class__.__name__.upper()
