from typing import TypeVar

from rabbitmq_proto_lib.converter.message_converter import RabbitMessageConverter

T = TypeVar('T')
from aio_pika import IncomingMessage


class StringMessageConverter(RabbitMessageConverter[str]):
    content_type = 'text/plain'

    def set_header(self, message: IncomingMessage) -> IncomingMessage:
        message.content_type = 'text/plain'

    async def encode_body(self, body: str) -> bytes:
        return body.encode()

    async def decode_body(self, message: IncomingMessage) -> str:
        return message.body.decode()
