import asyncio
import uuid

import aiormq
from aio_pika import IncomingMessage

from listener import RabbitListener


class RabbitRPCClient(RabbitListener):
    """ Abstraction of the RabbitMQ RPC Client"""

    _futures = {}
    _timeout_in_millis = 10000

    async def on_message(self, body, message: IncomingMessage):
        if message.correlation_id in self._futures.keys():
            future = self._futures.pop(message.correlation_id)
            future.set_result(body)
            message.reply_to = None  # Answer is given, so reset the reply_to

    async def convert_send_and_reply(self, routing_key: str, body, exchange_name: str = None,
                                     properties: aiormq.spec.Basic.Properties = None):
        """Send a request and get an answer back asynchronous."""
        correlation_id = str(uuid.uuid4())
        future = self.loop.create_future()
        self._futures[correlation_id] = future
        if not properties:
            properties = aiormq.spec.Basic.Properties()
        properties.correlation_id = correlation_id
        properties.reply_to = self.name
        properties.expiration = self._timeout_in_millis

        await self.convert_and_send(routing_key, body, exchange_name, properties)

        return await asyncio.wait_for(future, timeout=self._timeout_in_millis / 1000)

    def convert_send_and_reply_sync(self, routing_key: str, body, exchange_name: str = None,
                                    properties: aiormq.spec.Basic.Properties = None):
        return self.loop.run_until_complete(
            self.convert_send_and_reply(routing_key, body, exchange_name, properties))

    """
    async def example_call(self, n):
        image = ImageProto(file_url="http://example.com/image.jpg")
        
        future_result = await self.convert_send_and_reply("asset.images.object.detect", image)

        return await self.future
    """
