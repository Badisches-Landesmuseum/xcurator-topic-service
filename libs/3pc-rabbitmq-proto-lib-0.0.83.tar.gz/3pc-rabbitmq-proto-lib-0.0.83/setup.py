from setuptools import setup, find_packages

setup(
    name='3pc-rabbitmq-proto-lib',  # How you named your package folder (MyLib)
    packages=find_packages(),  # Chose the same as "name"
    version='0.0.83',  # Start with a small number and increase it with every change you make
    license='MIT',  # Chose a license from here: https://help.github.com/articles/licensing-a-repository
    description='Easy to use and pre configuration of RabbitMQ and Proto in Python projects',
    # Give a short description about your library
    author='Sören Räuchle',  # Type in your name
    author_email='sraeuchle@3pc.de',  # Type in your E-Mail
    url='https://gitlab.3pc.de/3pc-python/rabbitmq-proto-lib',
    # Provide either the link to your github or to your website
    keywords=['3pc', 'Rabbit MQ', 'Proto', 'Protocol Buffers'],  # Keywords that define your package best
    entry_points={
        "console_scripts": ["protoc-gen-python_betterproto=betterproto.plugin:main"]
    },
    install_requires=[
        "pika>=1.1.0",
        "protobuf",
        "betterproto[compiler]",
        "retrying==1.3.3",
        "aio-pika==6.7.1",
        "nest-asyncio==1.4.3",
    ],
    classifiers=[
        'Development Status :: 3 - Alpha',
        # Chose either "3 - Alpha", "4 - Beta" or "5 - Production/Stable" as the current state of your package
        'Intended Audience :: Developers',  # Define that your audience are developers
        'Topic :: Software Development :: Python',
        'License :: OSI Approved :: MIT License',  # Again, pick a license
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
    ],
)
