# RabbitMQ - Proto Bibliothek

Author: Sören Räuchle @ 3pc GmbH

A Library to easy manage and integate RabbitMQ with binary Google Protobuf communication.
This Code is heavily based on the [aio_pika](https://aio-pika.readthedocs.io/en/latest/apidoc.html) Library

### Install
```pip install rabbitmq-proto-lib```

### Features
- Handle Threading for Asynchronous RabbitMQ Messaging
- Define default Message Properties | Queues attributes, Message Headers (Content-type, ...))
- Managing RabbitMQ Connection | Auto-reconnect, Channel creation
- Easy to Use, Publisher (RabbitPublisher), Consumer (RabbitListener)
- Auto Message encode / decode of Google Protobuf Data `

### Usage example

#### 1. Create an RabbitMQ Manager
```python
from rabbitmq_proto_lib.manager import RabbitManager

RABBIT_CONFIG = {'username': 'dreipc',
                 'password': 'password',
                 'host': 'localhost',
                 'port': 5672,
                 'vhost': '/'}

# If you you use the yml config:
app_config = YamlConfig.load()
RABBIT_CONFIG = app_config['rabbitmq']

rabbit_manager = RabbitManager(RABBIT_CONFIG, app_name="Example-Service")
```

#### 2. Consuming Messages

1.  Create an RabbitListener:

Attention: **Please make sure you are using the async / await annotations correctly!**
```python
from rabbitmq_proto_lib.listener import RabbitListener
from aio_pika import IncomingMessage


from proto.asset.objectdetection import ObjectProto # Example Proto / use yours 


class ExampleProtoListener(RabbitListener): # <<< Inherit from Rabbit Listener

    def __init__(self):
        self.name = "example.queue"  # <<< Define a queue name
        self.exchange_name = 'assets'                   # <<< Define exchange (topic), the queue will be binded to
        self.routing_keys = ['image.created']     # <<< Set routing Keys this listener should listen to
        self.dead_letter_exchange = "assets-dlx"        # <<< Set a Dead letter Exchange where all Messages will be routed due to Errors
        
        # Set more Queue settings by overriding the Attributes (inherited from: rabbitmq_proto_lib.models.RabbitQueue)
        # e.g.:
        # self.durable: bool = True           # Persist Messages in RabbitMQ 
        # self.auto_delete: bool = False      # Delete Queue if no consumers are listening
        # self.prefetch_count: int = 250      # Number of unacknoledged Messages which are fetched from RabbitMQ (Control of the speed of Data flow)
    

    async def on_message(self, body: ObjectProto, message: IncomingMessage): # NEEDED, Override the 'on_message' Method for receiving Messages
        # param: body: ObjectProto
        # Just add the type you are expecting to get on this Queue, the library will auto decode the message body
        # The auto decoder in the background is using the 'message.content-type' + the 'message,type' to know which Type it should be decode to.
        # The Proto Classes needed to be present in your code base!

        
        # param: message: IncomingMessage
        # The raw incoming Message will be also present for reading message properties or message headers
        print(self.name + " [x] Proto Received %r" % body.label)
        
        
        # REPLY (Request-Reply Pattern / RPC)
        # If you know you need to reply a message, in this case you can return the answer
        reply_answer = ObjectProto() # Answer for the incoming Message
        return reply_answer

        # Publish Event
        # If you want to publish an resulting event, this can be done by overriding 'convert_and_send'
        # Sending resulting_event with routing_key 'something.changed' to the exchange 'assets'
        resulting_event = ObjectProto() # Resulting Event 
        await self.convert_and_send('something.changed', resulting_event, 'assets')
        
```

#### 3. Start / Connect
```python
rabbit_manager.connect()   # Register your listener     
```

### Publish Library
1. ```python setup.py sdist```
2. ```twine upload -r pypi-3pc dist/*``

### Dependencies:
- aio_pika (RabbitMQ) | [Dokumentation](https://aio-pika.readthedocs.io/en/latest/apidoc.html)
- pika (RabbitMQ Bibliothek) | [GitHub](https://github.com/pika/pika)
- betterproto (Google Protocol Buffers) | [GitHub](https://github.com/danielgtaylor/python-betterproto)
- proto (Google Protocol Buffers) | [Dokumentation](https://developers.google.com/protocol-buffers/docs/pythontutorial)

